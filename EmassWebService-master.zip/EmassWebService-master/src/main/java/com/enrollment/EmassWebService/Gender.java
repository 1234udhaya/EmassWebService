package com.enrollment.EmassWebService;

public enum Gender {
	  M,F,U;
}
