package com.enrollment.EmassWebService;

import com.enrollment.EmassWebService.wsdl.EnrollmentResponseType;
import com.enrollment.EmassWebService.wsdl.EnrollmentType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.soap.client.core.SoapActionCallback;

public class EnrollmentTypeClient extends WebServiceGatewaySupport {
    private static final Logger log = LoggerFactory.getLogger(EnrollmentTypeClient.class);

    public EnrollmentResponseType getEnrollmentType() {
        EnrollmentType enrollmentType = new EnrollmentType();

        log.info("Requesting location for " + enrollmentType);

        EnrollmentResponseType responseType = (EnrollmentResponseType) getWebServiceTemplate()
                .marshalSendAndReceive("http://100.111.30.153:9191/connector/services/v4/EnrollmentSparse", enrollmentType,
                        new SoapActionCallback(
                                "http://www.healthedge.com/connector/schema/enrollmenttypes"));

        return responseType;
    }
}
