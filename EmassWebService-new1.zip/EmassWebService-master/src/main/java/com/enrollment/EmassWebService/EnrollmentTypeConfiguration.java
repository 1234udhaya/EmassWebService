package com.enrollment.EmassWebService;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@Configuration
public class EnrollmentTypeConfiguration {
    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath("com.enrollment.EmassWebService.wsdl");
        return marshaller;
    }

    @Bean
    public EnrollmentTypeClient enrollmentTypeClient(Jaxb2Marshaller marshaller) {
        EnrollmentTypeClient enrollmentTypeClient = new EnrollmentTypeClient();
        enrollmentTypeClient.setDefaultUri("http://100.111.30.153:9191/connector/services/v4/");
        enrollmentTypeClient.setMarshaller(marshaller);
        enrollmentTypeClient.setUnmarshaller(marshaller);
        return enrollmentTypeClient;
    }
}
