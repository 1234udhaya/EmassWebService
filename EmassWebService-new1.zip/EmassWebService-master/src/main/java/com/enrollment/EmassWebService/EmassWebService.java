package com.enrollment.EmassWebService;

import com.enrollment.EmassWebService.dto.*;
import com.enrollment.EmassWebService.wsdl.EnrollmentResponseType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

import java.util.Map;

@SpringBootApplication
public class EmassWebService {

    @Autowired
    HealthEdge healthEdge = new HealthEdge();

    @Autowired
    Environment environment;

    @Autowired
    PersonalDetails personalDetails = new PersonalDetails();

    @Autowired
    ReadBaseDetails readBaseDetails = new ReadBaseDetails();

    @Autowired
    ReadAuthrep readAuthrep = new ReadAuthrep();

    @Autowired
    ReadELigDetails readELigDetails = new ReadELigDetails();

    @Autowired
    ReadLockDetails readLockDetails = new ReadLockDetails();


    public static void main(String[] args) {
        SpringApplication.run(EmassWebService.class, args);
    }

    @Bean
    CommandLineRunner lookup(EnrollmentTypeClient enrollmentTypeClient) {
        return args -> {
            EnrollmentResponseType response = enrollmentTypeClient.getEnrollmentType();
            System.err.println(response.getAccountChangeStatus());
        };
    }

    /*@Override
    public void run(String... args) throws Exception {
        new EmassWebServiceClient().callback();

        RecordPreparation recordPreparation = new RecordPreparation(personalDetails, readBaseDetails, readAuthrep, readELigDetails, readLockDetails);

        recordPreparation.HashMapFromTextFile();

        RecordProcessing recordProcessing = new RecordProcessing(healthEdge);
        Map<String, Map<String, String>> processedRecords = recordProcessing.processEntrollment(RecordPreparation.records);

       WriteResults.writeToTextFile(processedRecords);

        System.exit(1);
    }*/
}